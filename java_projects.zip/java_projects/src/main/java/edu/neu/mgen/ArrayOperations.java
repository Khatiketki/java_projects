package edu.neu.mgen;

public class ArrayOperations {

        public static void main(String[] args) {
        int[] abc = {1, 3, 5, 2, 5};
        // Find the length of the array
        int length = abc.length;
        System.out.println("Length of the array: " + length);
        // Find the last member of the array
        int lastMember = abc[length - 1];
        System.out.println("Last member of the array: " + lastMember);
        }
    }        

